for i in range(10):
    if i==5: break
    print i
print "EOP"

print "--------"

for i in range(10):
    if i==5: continue
    print i
print "EOP"
